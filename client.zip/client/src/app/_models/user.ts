export class User {
  userid: string;
  password: string;
  usertype: string;
}
